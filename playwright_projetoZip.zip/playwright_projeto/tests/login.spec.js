// @ts-check
const { test, expect } = require('@playwright/test');
test.beforeEach( async ({page}) => {
  await page.goto('https://automationpratice.com.br/')
});
test('Login positivo @loginPositivo', async ({ page }) => {
  
  await page.getByRole('link', { name: ' Login' }).click();
  await page.locator('#user').click();
  await page.locator('#user').fill('wagner@gmail.com');
  await page.locator('#password').click();
  await page.locator('#password').fill('123456');
  await page.getByRole('button', { name: 'login' }).click();
});

test('Login negativo @loginNegativo', async ({ page }) => {
  
  await page.getByRole('link', { name: ' Login' }).click();
  await page.locator('#user').click();
  await page.locator('#user').fill('wagner*rubro.com');
  await page.locator('#password').click();
  await page.locator('#password').fill('123456');
  await page.getByRole('button', { name: 'login' }).click();
  await page.getByText('E-mail inválido.').click();
});






